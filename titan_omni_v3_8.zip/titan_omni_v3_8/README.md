# TITAN-OMNI v3.8 Iron Stealth
Antigravity Generated Repository.

## Spec
- **System Mode:** PAPER (Strict)
- **Cycle:** 15m
- **Fail-Closed:** Yes
- **Persistence:** Supabase (Append-Only)
